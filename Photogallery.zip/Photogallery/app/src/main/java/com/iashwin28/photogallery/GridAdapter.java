package com.iashwin28.photogallery;

import android.content.Context;
import android.net.Uri;
import android.os.StrictMode;
import android.view.LayoutInflater;
import android.widget.GridView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class GridAdapter extends BaseAdapter {

    public Context m;
    public String[] name;
    public String[] path;

    public GridAdapter(Context a, String[] path, String[] name){
        m=a;
        this.name=name;
        this.path=path;
    }

    @Override
    public int getCount() {
        return 0;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

       ImageView abc = (ImageView) convertView.findViewById(R.id.imageView);
        abc.setImageURI(Uri.parse(getItem(position).toString()));
//

        return convertView;
    }


}
