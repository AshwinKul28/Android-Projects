package com.iashwin28.photogallery;



        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.content.pm.PackageManager;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.media.ThumbnailUtils;
        import android.net.Uri;
        import android.os.Bundle;
        import android.os.Environment;
        import android.provider.MediaStore;
        import android.support.v7.app.AppCompatActivity;
        import android.util.Log;
        import android.util.LruCache;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.BaseAdapter;
        import android.widget.GridView;
        import android.widget.ImageView;
        import android.widget.TextView;
        import java.io.BufferedReader;
        import java.io.File;
        import java.io.FileNotFoundException;
        import java.io.FileReader;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.text.SimpleDateFormat;
        import java.util.ArrayList;
        import java.util.Date;

        import android.support.v7.widget.Toolbar;
        import android.widget.Toast;


public class folder_layout extends AppCompatActivity{

    GridView gv;
    ArrayList<File> images;
    ArrayList<String> image_location;
    ArrayList<File> folder_url;
    int CALL_FROM_SUBCLASS=0;
    LruCache<File,Bitmap> myCache=new LruCache<>((int)Runtime.getRuntime().maxMemory()/64);
    String path[];
    String Photopath;
    ImageView img;
    static final int Image_capture=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.folder_layout);
        images=new ArrayList<>();
        Toolbar mytb = (Toolbar) findViewById(R.id.folder_toolbar);
        setSupportActionBar(mytb);
        image_location=new ArrayList<>();
        folder_url=new ArrayList<>();
        gv=(GridView)findViewById(R.id.gridView2);
        img = (ImageView) findViewById(R.id.Camview);
        scanForFolders();//This will scan for folders and assign the first image of each folder in the list alongwith the folder name
        //The ArrayLists will get populated after this, so call the CacheThread
        final CacheThread_folder cacheThread_folder=new CacheThread_folder();
        Log.e("Cache", "Folder bitmap cache population has started");
        cacheThread_folder.start();

        if(!hascamera()) {

            Toast.makeText(folder_layout.this, "Camera nahi hai", Toast.LENGTH_SHORT).show();
        }

        gv.setAdapter(new GridAdapter());
        path=new String[folder_url.size()];
        myCache.evictAll();
        Log.e("Cache","Evicted!");
        onTrimMemory(TRIM_MEMORY_RUNNING_LOW);
        Log.e("Memory", "Memory cleared");
        for(int i=0;i<folder_url.size();i++)
        {
            path[i]=folder_url.get(i).getAbsolutePath();
        }

        //ON GRID ITEM CLICK//
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ProgressDialog dialog = new ProgressDialog(folder_layout.this);
                dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                dialog.setMessage("Loading. Please wait...");
                dialog.setIndeterminate(true);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setMax(100);
                dialog.show();
                StartIntent pictureIntent=new StartIntent(position,dialog);
                pictureIntent.start();
            }
        });
    }



    private boolean hascamera()
    {
        return getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY);

    }

    private File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_PICTURES);
        if(storageDir == null)
        {
            storageDir.mkdir();
        }
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        Photopath = "file:" + image.getAbsolutePath();
        return image;
    }



    private void galleryAddPic() {
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File(Photopath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode==Image_capture && resultCode== RESULT_OK)
        {
            Bundle extras = data.getExtras();
            Bitmap photo = (Bitmap) extras.get("data");
            img.setImageBitmap(photo);
        }

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_settings:
                //settings
                return true;

            case R.id.action_camera:
                //camera
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if(intent.resolveActivity(getPackageManager()) != null)
                {
                    File photoFile = null;
                    try {
                        photoFile = createImageFile();
                    } catch (IOException ex) {
                        // Error occurred while creating the File
                        Toast.makeText(folder_layout.this, "Error creating file", Toast.LENGTH_SHORT).show();
                    }
                    if(photoFile != null)
                    {
                        intent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
                        startActivityForResult(intent, Image_capture);
                    }

                }
                return true;

//            case R.id.folder_view:
//                folderLayoutInflater();
//                return true;


            default:
                // If we got here, the user's action was not recognized.
                // Invoke the superclass to handle it.
                return super.onOptionsItemSelected(item);

        }
    }


    class StartIntent extends Thread{
        int position;
        ProgressDialog dialog;
        StartIntent(int position,ProgressDialog dialog)
        {
            this.position=position;
            this.dialog=dialog;
        }
        public void run()
        {
            Intent showImage = new Intent(folder_layout.this,ViewImageFolder.class);
            dialog.setProgress(25);
            showImage.putExtra("filepath", path);
            dialog.setProgress(50);
            dialog.setProgress(75);
            showImage.putExtra("position", position);
            dialog.setProgress(100);
            startActivity(showImage);
            dialog.dismiss();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        getMenuInflater().inflate(R.menu.action_menu, menu);
        return true;
    }
    class GridAdapter extends BaseAdapter
    {
        private Activity activity;
        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return images.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }//if we use database

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            convertView= getLayoutInflater().inflate(R.layout.img_folder_layout,parent,false);
            ImageView newimg= (ImageView) convertView.findViewById(R.id.imageView_folder);
            TextView location=(TextView)convertView.findViewById(R.id.folder_name);
            newimg.setImageBitmap(myCache.get((File) getItem(position)));
            location.setText(image_location.get(position));
            new GridAdapter().notifyDataSetChanged();
            return convertView;
        }//this method will set each and every image to the grid view
        //TODO: Set the location of items in ArrayList and cache in such a manner such that the positions correspond
    }
    ////////////////////////////////////////////////////////////////////////////////////////////////////
    //FOLDER STUFF//
    protected void scanForFolders()
    {
        File root= Environment.getExternalStorageDirectory();
        getFilesAndPaths(root);
    }
    private void getFilesAndPaths(File root)
    {
        int count_add=0;
        File files[]=root.listFiles();
        Log.e("Files",String.valueOf(files.length));
        for(int i=0;i<files.length;i++)
        {
            if(files[i].isDirectory())
            {
                Log.e("Files","Found directory!");
                getFilesAndPaths(files[i]);
            }
            else
            {
                if(files[i].getName().endsWith(".jpg")) {
                    Log.e("Files",files[i].getName());
                    if (count_add < 1) {//This ensures that only the first image within a directory is selected
                        images.add(files[i]);
                        image_location.add(extractFolderName(files[i].getAbsolutePath()));//gets Folder name to set on the imageView
                        folder_url.add(files[i].getParentFile());//Sets the URL of the folder which should be scanned in the imageview gallery activity for that folder
                    }
                    count_add++;
                }
            }
        }
    }
    private String extractFolderName(String fileName)
    {
        int count=0;
        String folderName="";
        for(int i=fileName.length()-1;i>=0;i--)
        {
            if(fileName.charAt(i)=='/')
            {
                count++;
                for(int j=i-1;count!=2;j--)
                {
                    if(fileName.charAt(j)=='/')
                        count++;
                    else {
                        folderName = folderName + fileName.charAt(j);
                    }
                }
                folderName=new StringBuffer(folderName).reverse().toString();
                Log.e("Folder", folderName);
                break;
            }
        }
        return folderName;
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////////
    //CACHE STUFF//
    class CacheThread_folder extends Thread {
        public void run() {
            int CACHE_POPULATOR = 0;
            Log.e("File", String.valueOf(CACHE_POPULATOR));
            File folder = new File(Environment.getExternalStorageDirectory() + File.separator + "Gallery");
            boolean success = false;
            File cache_master = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "Gallery" + File.separator + "handler_folder.txt");
            if (!folder.exists()) {
                success = folder.mkdir();
                Log.e("File", "Cache Master has been generated");
                Log.e("File", String.valueOf(success));
                if (success) {
                    boolean result = false;
                    if (!cache_master.exists()) {
                        try {
                            result = cache_master.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    Log.e("File", String.valueOf(result));
                    if (result) {
                        try {
                            FileWriter master = new FileWriter(cache_master);
                            master.write("1");
                            master.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else {
                boolean success_of_file_creation = false;
                if (!cache_master.exists()) {
                    try {
                        success_of_file_creation = cache_master.createNewFile();
                        FileWriter folder_handler=new FileWriter(cache_master);
                        folder_handler.write("0");
                        folder_handler.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Log.e("File", "Else block executing");
                if (success_of_file_creation) {
                    try {
                        FileReader master = new FileReader(cache_master);
                        BufferedReader br = new BufferedReader(master);
                        if ((CACHE_POPULATOR = Integer.parseInt(br.readLine())) == 1) {
                            Log.e("Cache", "Cache has already been built");
                        } else {
                            FileWriter slave = new FileWriter(cache_master);
                            master.close();
                            slave.write("1");
                            slave.close();
                        }
                        master.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else
                {
                    Log.e("File","Failure in creation of folder cache populator file");
                }
            }
            if (CACHE_POPULATOR != 1) {
                Log.e("Folder Images Size", String.valueOf(images.size()));
                Log.e("Cache", String.valueOf(myCache.size()));
                for (int i = 0; i < images.size(); i++) {
                    myCache.put(images.get(i), ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(images.get(i).toString()), 100, 100));
                    if (((int) Runtime.getRuntime().maxMemory() - myCache.size()) < 10000) {
                        Log.e("Cache", "Cache Evicted");
                        myCache.evictAll();
                    }
                    Log.e("Cache", String.valueOf(myCache.size()));
                    CACHE_POPULATOR = 1;
                    yield();
                }
            }
        }
    }
    @Override
    protected void onDestroy() {
        super.onDestroy();
        File subclass_checker=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator+"Gallery"+File.separator+"onDestroychecker_folder.txt");
        try
        {
            Log.e("File","Subclass call checking sequence initiated!");
            FileReader checker=new FileReader(subclass_checker);
            BufferedReader br=new BufferedReader(checker);
            if(Integer.parseInt(br.readLine())==1){
                Log.e("File","CALL FROM SUBCLASS");
                CALL_FROM_SUBCLASS=1;
                checker.close();
                FileWriter checker_write=new FileWriter(subclass_checker);
                checker_write.write("0");
                checker_write.close();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch(IOException e){
            e.printStackTrace();
        }
        if(CALL_FROM_SUBCLASS!=1) {
            File cache_master = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "DebaGallery" + File.separator + "handler.txt");
            try {
                Log.e("File", String.valueOf(cache_master.exists()));
                FileWriter master = new FileWriter(cache_master);
                Log.e("File", "Reinitialized to 0");
                master.write("0");
                master.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        CALL_FROM_SUBCLASS=0;
    }



}
