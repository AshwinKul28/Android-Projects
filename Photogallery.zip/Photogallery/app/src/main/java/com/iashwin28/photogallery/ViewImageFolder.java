package com.iashwin28.photogallery;



        import android.app.Activity;
        import android.app.ProgressDialog;
        import android.content.Intent;
        import android.graphics.Bitmap;
        import android.graphics.BitmapFactory;
        import android.media.ThumbnailUtils;
        import android.os.Bundle;
        import android.os.Environment;
        import android.util.Log;
        import android.util.LruCache;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.AdapterView;
        import android.widget.BaseAdapter;
        import android.widget.GridView;
        import android.widget.ImageView;
        import java.io.BufferedReader;
        import java.io.File;
        import java.io.FileNotFoundException;
        import java.io.FileReader;
        import java.io.FileWriter;
        import java.io.IOException;
        import java.util.ArrayList;


//TODO: On grid item click, new activity showing particular image should start
public class ViewImageFolder extends folder_layout {

    GridView gv;
    ArrayList<File> images;
    int CALL_FROM_SUBCLASS=0;
    int position;
    String filepath[];
    String path[],name[];
    LruCache<File,Bitmap> myCache=new LruCache<>((int)Runtime.getRuntime().maxMemory()/64);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewimage_folder);
        Intent i = getIntent();
        images=new ArrayList<>();
        gv=(GridView)findViewById(R.id.gridView3);
        position = i.getExtras().getInt("position");
        filepath = i.getStringArrayExtra("filepath");
        Log.e("Files",filepath[position]);
        File root=new File(filepath[position]);
        images=imageReader(root);
        final CacheThread_each_folder cacheThread_each_folder=new CacheThread_each_folder();
        Log.e("Cache","This folder cache population has started");
        cacheThread_each_folder.start();
        gv.setAdapter(new GridAdapter());
        path=new String[images.size()];
        name=new String[images.size()];
        myCache.evictAll();
        Log.e("Cache","Evicted!");
        onTrimMemory(TRIM_MEMORY_RUNNING_LOW);
        Log.e("Memory", "Memory cleared");
        for(int j=0;j<images.size();j++)
        {
            path[j]=images.get(j).getAbsolutePath();
            name[j]=images.get(j).getName();
//            myCache.put(images.get(i), ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(images.get(i).toString()), 100, 100));
        }
        gv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                ProgressDialog dialog = new ProgressDialog(ViewImageFolder.this);
                dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                dialog.setMessage("Loading. Please wait...");
                dialog.setIndeterminate(true);
                dialog.setCanceledOnTouchOutside(false);
                dialog.setMax(100);
                dialog.show();
                StartIntent_subclass pictureIntent=new StartIntent_subclass(position,dialog);
                pictureIntent.start();
            }
        });
    }
    class StartIntent_subclass extends Thread{
        int position;
        ProgressDialog dialog;
        StartIntent_subclass(int position,ProgressDialog dialog)
        {
            this.position=position;
            this.dialog=dialog;
        }
        public void run()
        {
            Intent showImage = new Intent(ViewImageFolder.this,ViewImage.class);
            dialog.setProgress(25);
            showImage.putExtra("filepath", path);
            dialog.setProgress(50);
            showImage.putExtra("filename", name);
            dialog.setProgress(75);
            showImage.putExtra("position", position);
            dialog.setProgress(100);
            startActivity(showImage);
            dialog.dismiss();
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    //ADAPTER//
    class GridAdapter extends BaseAdapter
    {
        private Activity activity;
        @Override
        public int getCount() {
            return images.size();
        }

        @Override
        public Object getItem(int position) {
            return images.get(position);
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }//if we use database

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            convertView= getLayoutInflater().inflate(R.layout.singleview_folder,parent,false);
            ImageView newimg= (ImageView) convertView.findViewById(R.id.imageView_each_folder);
//            newimg.setImageBitmap(ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(getItem(position).toString()), 100, 100));
            newimg.setImageBitmap(myCache.get((File) getItem(position)));
            new GridAdapter().notifyDataSetChanged();
            return convertView;
        }//this method will set each and every image to the grid view
    }
    //////////////////////////////////////////////////////////////////////////////////////////////////
    //CACHE STUFF//
    class CacheThread_each_folder extends Thread {
        public void run() {
            int CACHE_POPULATOR = 0;
            Log.e("File", String.valueOf(CACHE_POPULATOR));
            File folder = new File(Environment.getExternalStorageDirectory() + File.separator + "Gallery");
            boolean success = false;
            File cache_master = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + File.separator + "Gallery" + File.separator + "handler_each_folder.txt");
            if (!folder.exists()) {
                success = folder.mkdir();
                Log.e("File", "Cache Master has been generated");
                Log.e("File", String.valueOf(success));
                if (success) {
                    boolean result = false;
                    if (!cache_master.exists()) {
                        try {
                            result = cache_master.createNewFile();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                    Log.e("File", String.valueOf(result));
                    if (result) {
                        try {
                            FileWriter master = new FileWriter(cache_master);
                            master.write("1");
                            master.close();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    }
                }
            } else {
                boolean success_of_file_creation = false;
                if (!cache_master.exists()) {
                    try {
                        success_of_file_creation = cache_master.createNewFile();
                        FileWriter folder_handler=new FileWriter(cache_master);
                        folder_handler.write("0");
                        folder_handler.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                Log.e("File", "Else block executing");
                if (success_of_file_creation) {
                    try {
                        FileReader master = new FileReader(cache_master);
                        BufferedReader br = new BufferedReader(master);
                        if ((CACHE_POPULATOR = Integer.parseInt(br.readLine())) == 1) {
                            Log.e("Cache", "Cache has already been built");
                        } else {
                            FileWriter slave = new FileWriter(cache_master);
                            master.close();
                            slave.write("1");
                            slave.close();
                        }
                        master.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else
                {
                    Log.e("File","Failure in creation of folder cache populator file");
                }
            }
            if (CACHE_POPULATOR != 1) {
                Log.e("Folder Images Size", String.valueOf(images.size()));
                Log.e("Cache", String.valueOf(myCache.size()));
                for (int i = 0; i < images.size(); i++) {
                    myCache.put(images.get(i), ThumbnailUtils.extractThumbnail(BitmapFactory.decodeFile(images.get(i).toString()), 100, 100));
                    if (((int) Runtime.getRuntime().maxMemory() - myCache.size()) < 10000) {
                        Log.e("Cache", "Cache Evicted");
                        myCache.evictAll();
                    }
                    Log.e("Cache", String.valueOf(myCache.size()));
                    CACHE_POPULATOR = 1;
                    yield();
                }
            }
        }
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////
    ArrayList<File> a = new ArrayList<>();

    ArrayList<File> imageReader(File root) {

        addtolist(root);
        return a;
    }
    void addtolist(File root) {
        File files[] = root.listFiles();
        for (int i = 0; i < files.length; i++) {
            if (!files[i].isDirectory()) {
                if (files[i].getName().endsWith(".jpg")) {
                    a.add(files[i]);
                }
            }
        }
    }

    //ON DESTROY
    @Override
    protected void onDestroy() {
        File cache_master=new File(Environment.getExternalStorageDirectory().getAbsolutePath()+File.separator+"Gallery"+File.separator+"onDestroychecker_folder.txt");
        boolean success;
        if(!cache_master.exists())
        {
            try {
                success=cache_master.createNewFile();
                Log.e("File", String.valueOf(success));
            } catch (IOException e) {
                e.printStackTrace();
            }
            Log.e("File","Subclass else block executing");
            try {
                Log.e("File",String.valueOf(cache_master.exists()));
                FileWriter master= new FileWriter(cache_master);
                Log.e("File", "Initialized CALL_FROM_SUBCLASS to 1");
                master.write("1");
                master.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        else
        {
            Log.e("File","Subclass else block executing");
            try {
                Log.e("File",String.valueOf(cache_master.exists()));
                FileWriter master= new FileWriter(cache_master);
                Log.e("File", "Initialized CALL_FROM_SUBCLASS to 1");
                master.write("1");
                master.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        super.onDestroy();
        Log.e("File", "ViewImage_folder Activity destroyed!");
    }
}
