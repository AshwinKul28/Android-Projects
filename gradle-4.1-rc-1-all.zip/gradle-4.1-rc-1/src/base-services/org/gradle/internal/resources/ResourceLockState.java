/*
 * Copyright 2017 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.gradle.internal.resources;

public interface ResourceLockState {
    /**
     * Possible results from a resource lock state transform.
     */
    enum Disposition { FAILED, FINISHED, RETRY }

    /**
     * Registers a resource lock to be rolled back if the transform associated with this resource lock state
     * fails.
     *
     * @param resourceLock
     */
    void registerLocked(ResourceLock resourceLock);

    /**
     * Registers a resource lock that has been unlocked during the transform so that the coordination service can
     * notify threads waiting on a lock.
     *
     * @param resourceLock
     */
    void registerUnlocked(ResourceLock resourceLock);

    /**
     * Release any locks that have been acquired during the transform.
     */
    void releaseLocks();
}
